# API GENERATIVE AI

### INSTALL REQUIREMENTS

```
pip install -r requirements.txt
pip install google-cloud-aiplatform
```

### RUN

```
uvicorn main:app --reload
```

### DOCUMENTATION

```
base_url/docs
```
