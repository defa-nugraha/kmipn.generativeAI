from app.api.v1.GetDetailNewsByGenAI import GetDetailNewsByGenAI


GetDetailNewsByGenAI.scrape_dynamic("https://sulbartv.com/2024/05/01/smsi-dan-kedubes-iran-sepakat-jalin-kerja-sama/", "dihuhe7")